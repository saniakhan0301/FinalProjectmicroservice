package com.cg.hms.Register.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hms.Register.Entities.User;

public interface RegisterDao extends JpaRepository<User, Integer> {

}
