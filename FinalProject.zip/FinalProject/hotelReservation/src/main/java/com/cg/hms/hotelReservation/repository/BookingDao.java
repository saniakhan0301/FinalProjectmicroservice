package com.cg.hms.hotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.hms.hotelReservation.entities.BookingDetails;

public interface BookingDao extends JpaRepository<BookingDetails, Integer> 
{

}
