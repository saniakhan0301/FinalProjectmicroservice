package com.cg.hms.hotelReservation.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;




@Entity
@Table(name="bookingdetails")
public class BookingDetails 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_booking_id",allocationSize=1)
	@Column(name="booking_id")
	private int bookingId;
	@Column(name="hotel_id")
	private int	hotelID;
	@Column(name="user_id")
	private int	userId;
	@Column(name="booked_from")
	private Date bookedFrom;
	@Column(name="booked_to")
	private Date bookedTo;
	@Column(name="no_of_adults")
	private int	noOfAdults;
	@Column(name="no_of_children")
	private	int noOfChildren;
	@Column(name="amount")
	private	float amount;
	@Column(name="room_id")
	private int roomId;
	
	
	public BookingDetails() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public BookingDetails(int bookingId, int hotelID, int userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChildren,
			float amount, int roomId) 
	{
		super();
		this.bookingId = bookingId;
		this.hotelID = hotelID;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
		this.roomId = roomId;
	}
	
	
	public int getBookingId() 
	{
		return bookingId;
	}
	
	
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	
	
	public int getHotelID() {
		return hotelID;
	}
	
	
	public void setHotelID(int hotelID) {
		this.hotelID = hotelID;
	}
	
	
	public int getUserId() {
		return userId;
	}
	
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	public Date getBookedFrom() {
		return bookedFrom;
	}
	
	
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	
	
	public Date getBookedTo() {
		return bookedTo;
	}
	
	
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}
	
	
	public int getNoOfAdults() {
		return noOfAdults;
	}
	
	
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	
	
	public int getNoOfChildren() {
		return noOfChildren;
	}
	
	
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	
	
	public float getAmount() {
		return amount;
	}
	
	
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	
	public int getRoomId() {
		return roomId;
	}
	
	
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	
	
	@Override
	public String toString() {
		return "BookingDetails [bookingId=" + bookingId + ", hotelID=" + hotelID
				+ ", userId=" + userId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildren=" + noOfChildren + ", amount=" + amount
				+ ", roomId=" + roomId + "]";
	}
	

}
