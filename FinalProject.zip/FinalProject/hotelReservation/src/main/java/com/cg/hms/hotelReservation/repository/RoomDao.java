package com.cg.hms.hotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.hms.hotelReservation.entities.RoomDetails;

public interface RoomDao extends JpaRepository<RoomDetails, Integer>
{
	public RoomDetails findByHotelIDAndRoomId(Integer hotelId,Integer roomId);
}
