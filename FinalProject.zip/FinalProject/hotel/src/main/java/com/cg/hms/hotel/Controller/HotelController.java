package com.cg.hms.hotel.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.hotel.dao.HotelDao;
import com.cg.hms.hotel.entities.HotelDetails;
import com.cg.hms.hotel.entities.ResponseClient;


@RestController
public class HotelController {
    @Autowired
HotelDao hbd;

    @PostMapping(value="/insert/hotel",consumes=MediaType.APPLICATION_XML_VALUE)
    public ResponseClient insert(@RequestBody HotelDetails hb )
    {
        hbd.save(hb);
        ResponseClient res=new ResponseClient();
        res.setResponse("****Successfully Inserted****\n Your Hotel ID is "+hb.getHotelId());
        return res;
    }
    
    @GetMapping(value="/retrieveById/{hotelId}",produces=MediaType.APPLICATION_XML_VALUE)
    public HotelDetails retrieveHotel(@PathVariable("hotelId") int hotelId)
    {
    	HotelDetails h1=hbd.findById(hotelId).get();
        return h1;
    }
    
    //User Defined Function
    @GetMapping("/retrieveByCity/{city}")
    public ArrayList<HotelDetails> retrieveByName(@PathVariable("city") String city)
    {
        ArrayList<HotelDetails> h2=hbd.findByCity(city);
        return h2;  
    }
        
    @GetMapping(value="/retrieveAll")
    public List<HotelDetails> getAll()
    {
    return  hbd.findAll();
            
    }
        
        
    @DeleteMapping("/delete/{hotelId}")
    public String deleteEmployee(@PathVariable("hotelId") int hotelId)
    {
        hbd.deleteById(hotelId);
        return "Deleted";
    }
        
    @PutMapping("/update/{hotelId}/{description}")
    public String updateDescription(@PathVariable("hotelId") int hotelId,@PathVariable("description") String description) 
    {
    	HotelDetails h3=hbd.findById(hotelId).get();
        h3.setDescription(description);
        hbd.save(h3);
        return "Updated";
    }
    
    

    
}
