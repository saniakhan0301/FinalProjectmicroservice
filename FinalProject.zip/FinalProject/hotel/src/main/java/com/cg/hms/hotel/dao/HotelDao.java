package com.cg.hms.hotel.dao;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hms.hotel.entities.HotelDetails;




public interface HotelDao extends JpaRepository<HotelDetails, Integer> {

    
    public ArrayList<HotelDetails> findByCity(String city );
    
    
}
