package com.cg.Client.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="roomdetails")
public class RoomDetails 
{
	@Id

	@Column(name="room_id")
	private int roomId;
	@Column(name="hotel_id")
	private int hotelID;
	@Column(name="room_no")
	private int roomNo;
	@Column(name="room_type")
	private String roomType;
	@Column(name="per_night_rate")
	private float cost;
	@Column(name="availability")
	private String availability;
	@Column(name="photo")
	private String photo;
	
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getHotelID() {
		return hotelID;
	}
	public void setHotelID(int hotelID) {
		this.hotelID = hotelID;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public RoomDetails() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public RoomDetails(int roomId, int hotelID, int roomNo, String roomType,
			float cost, String availability, String photo) {
		super();
		this.roomId = roomId;
		this.hotelID = hotelID;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.cost = cost;
		this.availability = availability;
		this.photo = photo;
	}
	@Override
	public String toString() {
		return "RoomDetails [roomId=" + roomId + ", hotelID=" + hotelID
				+ ", roomNo=" + roomNo + ", roomType=" + roomType + ", cost="
				+ cost + ", availability=" + availability + ", photo=" + photo
				+ "]";
	}
	
	
}
