package com.cg.Client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.Client.entities.BookingDetails;
import com.cg.Client.entities.HotelDetails;
import com.cg.Client.entities.ResponseClient;
import com.cg.Client.entities.RoomDetails;
import com.cg.Client.entities.User;
import com.google.common.net.MediaType;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;




@RefreshScope
@RestController
public class ClientController
{
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private EurekaClient eurekaClient;
	
	
	@RequestMapping("/dashboard/{id}")
	    public BookingDetails findme(@PathVariable int id) {
		 System.out.println("this function is called");
	        Application application = eurekaClient.getApplication("booking");
	        InstanceInfo instanceInfo = application.getInstances().get(0);
	        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/status/" + id;
	        System.out.println("URL" + url);
	        BookingDetails booking = restTemplate.getForObject(url, BookingDetails.class);
	        return booking;
	    }
	
	@RequestMapping("/dashboard2/{id}")
    public RoomDetails findme2(@PathVariable int id) {
	 System.out.println("this function is called");
        Application application = eurekaClient.getApplication("room");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/select/Room/" + id;
        System.out.println("URL" + url);
        RoomDetails room= restTemplate.getForObject(url,RoomDetails.class);
        return room;
    }
	
	
	@RequestMapping("/dashboard3/{id}")
    public HotelDetails findme3(@PathVariable int id) {
	 System.out.println("this function is called");
        Application application = eurekaClient.getApplication("hotel");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/retrieveById/" + id;
        System.out.println("URL" + url);
        HotelDetails hotel = restTemplate.getForObject(url, HotelDetails.class);
        return hotel;
    }
	
	
	
	
	
	@GetMapping(value="/dashboard4/{userId}/{password}")
	public String findDetails(@PathVariable("userId") int userId,@PathVariable("password") String password)
	{
		
		Application app=eurekaClient.getApplication("register");
		InstanceInfo instanceInfo=app.getInstances().get(0);
		
		String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/login/"+userId+"/"+password;
		
		System.out.println("\n URL"+url);
		ResponseClient bd=restTemplate.getForObject(url,ResponseClient.class);
		String str=bd.getResponse();
		System.out.print("Response"+bd);
		return str;
	}
	
	@PostMapping(value="/dashboard5/register")
	public String findDetails1(@RequestBody User user)
	{
		
		Application app=eurekaClient.getApplication("register");
		InstanceInfo instanceInfo=app.getInstances().get(0);
		
		String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/register";
		
		ResponseClient bd= restTemplate.postForObject(url,user,ResponseClient.class);
		String str=bd.getResponse();
		
		return str;
		
	}
	@PostMapping(value="/dashboard6/insert/hotel")
	public String insertHotel(@RequestBody HotelDetails hd)
	{
		
		Application app=eurekaClient.getApplication("hotel");
		InstanceInfo instanceInfo=app.getInstances().get(0);
		
		String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/insert/hotel";
		
		ResponseClient bd= restTemplate.postForObject(url,hd,ResponseClient.class);
		String str=bd.getResponse();
		
		return str;
		
	}
	
	@PostMapping(value="/dashboard7/insert/Room")
	public String insertRoom(@RequestBody RoomDetails rd)
	{
		
		Application app=eurekaClient.getApplication("room");
		InstanceInfo instanceInfo=app.getInstances().get(0);
		
		String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/insert/Room";
		
		ResponseClient bd= restTemplate.postForObject(url,rd,ResponseClient.class);
		String str=bd.getResponse();
		
		return str;
		
	}
	
	@PostMapping(value="/dashboard8/bookroom")
	public String bookRoom(@RequestBody BookingDetails booking)
	{
		
		Application app=eurekaClient.getApplication("booking");
		InstanceInfo instanceInfo=app.getInstances().get(0);
		
		String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/bookroom";
		
		ResponseClient bd= restTemplate.postForObject(url,booking,ResponseClient.class);
		String str=bd.getResponse();
		
		return str;
		
	}
	 
}
