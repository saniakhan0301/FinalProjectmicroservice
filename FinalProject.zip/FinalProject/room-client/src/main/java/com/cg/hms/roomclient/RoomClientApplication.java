package com.cg.hms.roomclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class RoomClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomClientApplication.class, args);
	}
}
