package com.cg.hms.roomclient.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hms.roomclient.Entities.RoomDetails;



public interface RoomDao extends JpaRepository<RoomDetails, Integer>
{

}
